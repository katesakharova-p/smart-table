export function initFiltering(elements) {

  const updateIndexes = (elements, indexes) => {
    Object.keys(indexes).forEach((elementName) => {
      elements[elementName].append(
        ...Object.values(indexes[elementName]).map(name => {
          const el = document.createElement('option');
          el.textContent = name;
          el.value = name;
          return el;
        })
      );
    });
  };

  const applyFiltering = (query, state, action) => {

    // reset filters
    if (action === 'reset') {
      Object.values(elements).forEach(el => {
        if (el && ['INPUT', 'SELECT'].includes(el.tagName)) {
          el.value = '';
        }
      });
      return query;
    }

    const filter = {};

    // сервер поддерживает только эти фильтры
    const allowed = ['seller', 'customer', 'totalFrom', 'totalTo'];

    Object.keys(elements).forEach(key => {
      const el = elements[key];

      if (
        el &&
        ['INPUT', 'SELECT'].includes(el.tagName) &&
        el.value &&
        allowed.includes(el.name)
      ) {
        filter[`filter[${el.name}]`] = el.value;
      }
    });

    return Object.keys(filter).length
      ? { ...query, ...filter }
      : query;
  };

  return {
    updateIndexes,
    applyFiltering
  };
}
