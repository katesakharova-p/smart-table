export function initPagination(elements, renderPageButton) {

  const { pages } = elements;
  const form = pages.closest('form');

  let pageCount;

  pages.addEventListener('change', (e) => {
    if (e.target.name === 'page') {
      form.requestSubmit();
    }
  });

  const applyPagination = (query, state, action) => {
    const limit = state.rowsPerPage;
    let page = state.page;

    if (action === 'first') page = 1;
    if (action === 'last') page = pageCount;
    if (action === 'prev') page = Math.max(1, page - 1);
    if (action === 'next') page = Math.min(pageCount, page + 1);

    return {
      ...query,
      limit,
      page
    };
  };

  const updatePagination = (total, { page, limit }) => {
    pageCount = Math.ceil(total / limit);

    pages.innerHTML = '';

    const create = (i) => {
      const el = document.createElement('label');
      el.className = 'pagination__page';

      el.innerHTML = `
        <input type="radio" name="page">
        <span></span>
      `;

      renderPageButton(el, i, i === page);
      pages.append(el);
    };

    // первая
    create(1);

    // диапазон вокруг текущей
    for (let i = page - 2; i <= page + 2; i++) {
      if (i > 1 && i < pageCount) {
        create(i);
      }
    }

    // последняя
    if (pageCount > 1) {
      create(pageCount);
    }
  };

  return {
    applyPagination,
    updatePagination
  };
}
